﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App10 : Form
    {
        public App10()
        {
            InitializeComponent();
        }

        private void App10_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                ProgressBar progres = new ProgressBar();
                progres.Location = new Point(0, i * 25);
                this.Controls.Add(progres);
            }

            timer1.Start();
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random random = new Random();

            foreach(ProgressBar progres in this.Controls){
                progres.Value = random.Next(0, 100);
            }
        }
    }
}
