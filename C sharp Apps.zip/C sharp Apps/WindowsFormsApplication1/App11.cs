﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App11 : Form
    {
        public App11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dictionary<char, int> occ = new Dictionary<char, int>();
            string s = textBox1.Text;

            for (int i = 0; i < s.Length; ++i)
            {
                if (!occ.ContainsKey(s[i]))
                    occ[s[i]] = 0;
                occ[s[i]]++;
            }

            string oute = "";
            foreach (var c in occ)
            {
                if (c.Value > 0)
                    oute += c.Key + ": " + c.Value;

                oute += "\n";
            }
            MessageBox.Show(oute);
        }
    }
}
