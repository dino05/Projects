﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class App12 : Form
    {
        private int selectedPictureIndex = 0;
        private List<string> files = null;

        public App12()
        {
            InitializeComponent();
        }

        private void App12_Load(object sender, EventArgs e)
        {
            this.files = new List<string>();
            this.folderBrowserDialog1.ShowDialog();
            this.files.AddRange(Directory.GetFiles(this.folderBrowserDialog1.SelectedPath));
            this.files = this.files.Where(path => path.EndsWith(".jpg")).ToList();

            this.pictureBox1.ImageLocation = this.files.ElementAt(this.selectedPictureIndex);
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (this.selectedPictureIndex != this.files.Count - 1)
                {
                    this.pictureBox1.ImageLocation = this.files.ElementAt(++this.selectedPictureIndex);
                }
                else
                {
                    this.selectedPictureIndex = 0;
                    this.pictureBox1.ImageLocation = this.files.ElementAt(this.selectedPictureIndex);
                }
            }
            else
            {
                if (this.selectedPictureIndex != 0)
                {
                    this.pictureBox1.ImageLocation = this.files.ElementAt(--this.selectedPictureIndex);
                }
                else
                {
                    this.selectedPictureIndex = this.files.Count - 1;
                    this.pictureBox1.ImageLocation = this.files.ElementAt(this.selectedPictureIndex);
                }
            }
        }
    }
}
