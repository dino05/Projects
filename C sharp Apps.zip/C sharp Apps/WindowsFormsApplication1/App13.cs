﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App13 : Form
    {
        public App13()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            List<int> ext = new List<int>();
            int newNum = 0;
            int hits = 0;
            
            for (int i = 0; i < 7; i++)
            {
                do
                {
                    newNum = rand.Next(1, 45);
                } while (ext.Contains(newNum));
                
                ext.Add(newNum);
            }
            
            this.textBox8.Text = "";
            
            foreach (int number in ext)
            {
                this.textBox8.Text += number.ToString() + ",";
            }
            
            this.textBox8.Text = this.textBox8.Text.Substring(0, this.textBox8.Text.Length - 1);
            
            for (int i = 1; i <= 7; i++)
            {
                TextBox textBox = (TextBox)this.Controls.Find("textBox" + i, false).First();
                
                if (ext.Contains(int.Parse(textBox.Text)))
                {
                    hits++;
                }
            }
            
            string price = "";
            
            switch (hits)
            {
                case 1 - 4: price = "Nema nagrade..";
                    break;
                case 5: price = "Nagrada: 1000 kn";
                    break;
                case 6: price = "Nagrada: 10 000 kn";
                    break;
                case 7: price = "Nagrada: 1 000 000 kn";
                    break;
                default: price = "Nema nagrade..";
                    break;
            }
            MessageBox.Show(price);
        }
    }
}
