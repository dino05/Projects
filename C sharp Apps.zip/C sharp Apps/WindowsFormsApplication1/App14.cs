﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App14 : Form
    {
        public App14()
        {
            InitializeComponent();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            int number = 0;
            if (e.KeyCode == Keys.Enter)
            {
                if (int.TryParse(this.textBox1.Text, out number) && !listBox1.Items.Contains(number))
                {
                    this.listBox1.Items.Add(number);
                }
                this.textBox1.Text = "";
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            int number = 0;
            if (e.KeyCode == Keys.Enter)
            {
                if (int.TryParse(this.textBox2.Text, out number) && !listBox2.Items.Contains(number))
                {
                    this.listBox2.Items.Add(number);
                }
                this.textBox2.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.listBox3.Items.Clear();
            foreach (int item in this.listBox1.Items)
            {
                if (!this.listBox2.Items.Contains(item))
                {
                    this.listBox3.Items.Add(item);
                }
            }
            foreach (int item in this.listBox2.Items)
            {
                this.listBox3.Items.Add(item);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.listBox3.Items.Clear();
            foreach (int item in this.listBox1.Items)
            {
                if (this.listBox2.Items.Contains(item))
                {
                    this.listBox3.Items.Add(item);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.listBox3.Items.Clear();
            foreach (int item in this.listBox1.Items)
            {
                if (!this.listBox2.Items.Contains(item))
                {
                    this.listBox3.Items.Add(item);
                }
            }
            foreach (int item in this.listBox2.Items)
            {
                if (!this.listBox1.Items.Contains(item))
                {
                    this.listBox3.Items.Add(item);
                }
            }
        }
    }
}
