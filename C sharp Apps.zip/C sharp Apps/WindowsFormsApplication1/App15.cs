﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App15 : Form
    {
        public App15()
        {
            InitializeComponent();
        }

        private void App15_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'northwndDataSet.Suppliers' table. You can move, or remove it, as needed.
            this.suppliersTableAdapter.Fill(this.northwndDataSet.Suppliers);
            // TODO: This line of code loads data into the 'northwndDataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.northwndDataSet.Products);

            ClearSelection();

            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
            dataGridView2.Sort(dataGridView2.Columns[0], ListSortDirection.Ascending);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1 || dataGridView2.SelectedRows.Count != 1)
            {
                MessageBox.Show("Potrebno odabrati po jedan redak iz svake skupine.");
            }
            else
            {
                var selectedProductCell = dataGridView1.SelectedRows[0].Cells[0];
                var selectedSupplierCell = dataGridView2.SelectedRows[0].Cells[0];

                string product = selectedProductCell.Value.ToString();
                string supplier = selectedSupplierCell.Value.ToString();

                if (productsTableAdapter.IsConnected(product, supplier) != null)
                {
                    selectedProductCell.Style.BackColor = Color.Green;
                    selectedSupplierCell.Style.BackColor = Color.Green;
                }
                else
                {
                    selectedProductCell.Style.BackColor = Color.Red;
                    selectedSupplierCell.Style.BackColor = Color.Red;
                }

                ClearSelection();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                dr.Cells[0].Style.BackColor = Color.White;
            }

            foreach (DataGridViewRow dr in dataGridView2.Rows)
            {
                dr.Cells[0].Style.BackColor = Color.White;
            }

            ClearSelection();
        }

        private void ClearSelection()
        {
            dataGridView1.ClearSelection();
            dataGridView2.ClearSelection();
        }
    }
}
