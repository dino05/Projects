﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App16 : Form
    {
        class Pravokutnik
        {
            private float visina, sirina;

            public Pravokutnik(float a, float b)
            {
                this.visina = a;
                this.sirina = b;
            }

            public float izracunajPovrsinu()
            {
                return visina * sirina;
            }

            public float izracunajOpseg()
            {
                return visina * 2 + sirina * 2;
            }

            public float izracunajDijagonalu()
            {
                return (float)Math.Sqrt(visina * visina + sirina * sirina);
            }
        }

        public App16()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pravokutnik pravokutnik = new Pravokutnik(int.Parse(textBox1.Text), int.Parse(textBox2.Text));
            textBox3.Text = pravokutnik.izracunajPovrsinu().ToString();
            textBox4.Text = pravokutnik.izracunajOpseg().ToString();
            textBox5.Text = pravokutnik.izracunajDijagonalu().ToString();
        }
    }
}
