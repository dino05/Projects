﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App17 : Form
    {
        private PogadanjeBrojeva igra;

        public App17()
        {
            InitializeComponent();
        }

        private void SakrijGeneriraneBrojeve()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void PrikaziGeneriraneBrojeve(List<int> generiraniBrojevi)
        {
            textBox1.Text = generiraniBrojevi[0].ToString();
            textBox2.Text = generiraniBrojevi[1].ToString();
            textBox3.Text = generiraniBrojevi[2].ToString();
            textBox4.Text = generiraniBrojevi[3].ToString();
            textBox5.Text = generiraniBrojevi[4].ToString();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            SakrijGeneriraneBrojeve();
            timer1.Stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            igra = new PogadanjeBrojeva();
            PrikaziGeneriraneBrojeve(igra.GeneriraniBrojevi);
            timer1.Start();
            timer1.Interval = 5000;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            igra.UneseniBrojevi.Add(int.Parse(textBox6.Text));
            igra.UneseniBrojevi.Add(int.Parse(textBox7.Text));
            igra.UneseniBrojevi.Add(int.Parse(textBox8.Text));
            igra.UneseniBrojevi.Add(int.Parse(textBox9.Text));
            igra.UneseniBrojevi.Add(int.Parse(textBox10.Text));

            bool vracenaVrijednost = igra.ProvjeraIspravnosti();

            if (vracenaVrijednost == false)
            {
                MessageBox.Show("Netocno!");
            }
            else
                MessageBox.Show("Pogodili ste!");
        }
    }
}
