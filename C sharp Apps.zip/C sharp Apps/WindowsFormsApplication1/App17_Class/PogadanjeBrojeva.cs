﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class PogadanjeBrojeva
    {
                public List<int> GeneriraniBrojevi = new List<int>();
        public List<int> UneseniBrojevi = new List<int>();

        public PogadanjeBrojeva()
        {
            GenerirajBrojeve();
        }

        private void GenerirajBrojeve() {
            Random random = new Random();

            for (int i = 0; i < 5; i++) {
                int x = random.Next(0,20);

                if (!GeneriraniBrojevi.Contains(x))
                {
                    GeneriraniBrojevi.Add(x);
                }
                else
                    i--;
            }
        }
        public bool ProvjeraIspravnosti() {
            bool z = true;

            foreach(int x in GeneriraniBrojevi){
                if (!UneseniBrojevi.Contains(x))
                {
                    z = false;
                }
            }
            return z;
        }
    }
}
