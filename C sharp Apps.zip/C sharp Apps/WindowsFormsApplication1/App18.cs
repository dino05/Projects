﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App18 : Form
    {
        List<Kontakt> kontakt = new List<Kontakt>();

        public App18()
        {
            InitializeComponent();
            UkljuciKontrole(false);
        }

        private void UkljuciKontrole(bool ukljuci)
        {
            bool zastavica = ukljuci;

            if (zastavica == true)
            {
                textBox1.ReadOnly = false;
                textBox2.ReadOnly = false;
                textBox3.ReadOnly = false;
                textBox4.ReadOnly = false;
                comboBox1.Enabled = true;
                button2.Enabled = true;
                button1.Enabled = false;
            }

            else if (zastavica == false)
            {
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = true;
                textBox3.ReadOnly = true;
                textBox4.ReadOnly = true;
                comboBox1.Enabled = false;
                button2.Enabled = false;
                button1.Enabled = true;
            }
        }

        private void PrikaziKontakt(Kontakt kontak)
        {
            Kontakt kontMetoda = new Kontakt();
            kontMetoda = kontak;

            foreach (Kontakt k in kontakt)
            {
                if (k.Ime == kontMetoda.Ime && k.Prezime == kontMetoda.Prezime)
                {
                    textBox1.Text = k.Ime;
                    textBox2.Text = k.Prezime;
                    textBox3.Text = k.Email;
                    textBox4.Text = k.Telefon;
                    comboBox1.Text = k.Grupa.NazivGrupe;
                }
            }
        }

        private void OsvjeziPrikaz()
        {
            comboBox1.Items.Add(comboBox1.Text);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void OsvjeziPrikaz(string trazi)
        {
            string pojam = trazi;

            foreach (Kontakt k in kontakt)
            {
                if (k.Ime == pojam || k.Prezime == pojam || k.Email == pojam || k.Telefon == pojam)
                {
                    listBox1.Items.Add(k.Ime + " " + k.Prezime);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UkljuciKontrole(true);
            OsvjeziPrikaz();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UkljuciKontrole(false);

            Kontakt kont = new Kontakt();
            kont.Ime = textBox1.Text;
            kont.Prezime = textBox2.Text;
            kont.Email = textBox3.Text;
            kont.Telefon = textBox4.Text;
            string grupaForm = comboBox1.Text;
            kont.Grupa = new Grupa(grupaForm);

            kontakt.Add(kont);

            listBox1.Items.Add(kontakt.Last().Ime + " " + kontakt.Last().Prezime);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string imeprez = listBox1.SelectedItem.ToString();
            Kontakt kont = new Kontakt();
            string[] polje = imeprez.Split(' ');
            kont.Ime = polje[0];
            kont.Prezime = polje[1];

            PrikaziKontakt(kont);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string tekst = textBox5.Text;
            OsvjeziPrikaz(tekst);
        }
    }
}
