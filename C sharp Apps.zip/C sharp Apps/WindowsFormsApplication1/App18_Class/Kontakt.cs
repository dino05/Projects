﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Kontakt
    {
        public string Ime;
        public string Prezime;
        public string Email;
        public string Telefon;
        public Grupa Grupa;
    }
}
