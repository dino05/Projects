﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App19 : Form
    {
        List<Vozilo> VozilaUGarazi = new List<Vozilo>();

        public App19()
        {
            InitializeComponent();
        }

        private void OsvjeziPrikaz()
        {
            listBox1.Items.Clear();
            int br_auti = 0;
            int br_moto = 0;

            foreach (Vozilo v in VozilaUGarazi)
            {
                listBox1.Items.Add(v.Naziv + ": " + v.TipVozila);

                if (v.TipVozila == "Automobil")
                {
                    br_auti++;
                    label4.Text = br_auti.ToString();
                }

                if (v.TipVozila == "Motocikl")
                {
                    br_moto++;
                    label6.Text = br_moto.ToString();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Vozilo vozilo = new Vozilo();
            Motocikl motocikl = new Motocikl();
            Automobil automobil = new Automobil();
            string naziv = textBox1.Text;
            vozilo.Naziv = naziv;

            if (radioButton1.Checked)
            {
                vozilo.TipVozila = automobil.TipVozila;
            }

            if (radioButton2.Checked)
            {
                vozilo.TipVozila = motocikl.TipVozila;
            }

            VozilaUGarazi.Add(vozilo);
            textBox1.Clear();
            OsvjeziPrikaz();
        }
    }
}
