﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App2 : Form
    {
        public App2()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime datum = new DateTime();
            datum = dateTimePicker1.Value;

            DateTime pProljeca = new DateTime(datum.Year, 3, 21);
            DateTime pLjeta = new DateTime(datum.Year, 6, 21);
            DateTime pJeseni = new DateTime(datum.Year, 9, 23);
            DateTime pZime = new DateTime(datum.Year, 12, 21);

            if (datum >= pProljeca && datum < pLjeta)
            {
                label1.Text = "Proljeće";
            }

            if (datum >= pLjeta && datum < pJeseni)
            {
                label1.Text = "Ljeto";
            }

            if (datum >= pJeseni && datum < pZime)
            {
                label1.Text = "Jesen";
            }

            if (datum >= pZime || datum < pProljeca)
            {
                label1.Text = "Zima";
            }
        }
    }
}
