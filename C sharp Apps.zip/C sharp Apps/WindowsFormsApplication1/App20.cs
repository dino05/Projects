﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App20 : Form
    {
        List<WindowsFormsApplication1.App20_Class.Mjerenje> PopisMjerenja = new List<WindowsFormsApplication1.App20_Class.Mjerenje>();

        public App20()
        {
            InitializeComponent();
        }

        public void RacunajProsjek()
        {
            int suma = 0;
            decimal prosjek = 0;

            foreach (WindowsFormsApplication1.App20_Class.Mjerenje m in PopisMjerenja)
            {
                suma += m.Temperatura;
            }

            prosjek = suma / PopisMjerenja.Count;

            if (prosjek < 0)
            {
                label5.ForeColor = Color.Blue;
                label5.Text = prosjek.ToString();
            }

            else if (prosjek > 0)
            {
                label5.ForeColor = Color.Red;
                label5.Text = prosjek.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string naziv = textBox2.Text;
            int temp = int.Parse(textBox1.Text);
            DateTime vrijeme = dateTimePicker1.Value;

            WindowsFormsApplication1.App20_Class.Mjerenje mjerenje = new WindowsFormsApplication1.App20_Class.Mjerenje(naziv, temp, vrijeme);
            PopisMjerenja.Add(mjerenje);

            dataGridView1.Rows.Add(PopisMjerenja.Last().Naziv, PopisMjerenja.Last().Temperatura, PopisMjerenja.Last().Vrijeme);
            dataGridView1.Update();
            RacunajProsjek();
        }
    }
}
