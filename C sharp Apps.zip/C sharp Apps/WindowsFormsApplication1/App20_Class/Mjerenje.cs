﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.App20_Class
{
    class Mjerenje
    {
        public string Naziv;
        public int Temperatura;
        public DateTime Vrijeme;

        public Mjerenje(string naziv, int temp, DateTime vrijeme)
        {
            Naziv = naziv;
            Temperatura = temp;
            Vrijeme = vrijeme;
        }
    }
}
