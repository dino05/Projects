﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App21 : Form
    {
        List<WindowsFormsApplication1.App21_Class.MyColor> Colors = new List<WindowsFormsApplication1.App21_Class.MyColor>();

        public App21()
        {
            InitializeComponent();

            numericUpDown1.Minimum = 0;
            numericUpDown1.Maximum = 255;
            numericUpDown2.Minimum = 0;
            numericUpDown2.Maximum = 255;
            numericUpDown3.Minimum = 0;
            numericUpDown3.Maximum = 255;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WindowsFormsApplication1.App21_Class.MyColor color = new WindowsFormsApplication1.App21_Class.MyColor();

            color.Red = (int)numericUpDown1.Value;
            color.Green = (int)numericUpDown2.Value;
            color.Blue = (int)numericUpDown3.Value;
            color.Name = textBox1.Text;

            Colors.Add(color);

            var list = new BindingList<WindowsFormsApplication1.App21_Class.MyColor>(Colors);
            var source = new BindingSource(list, null);
            dataGridView1.DataSource = source;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb((int)numericUpDown1.Value, (int)numericUpDown2.Value, (int)numericUpDown3.Value);
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb((int)numericUpDown1.Value, (int)numericUpDown2.Value, (int)numericUpDown3.Value);
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb((int)numericUpDown1.Value, (int)numericUpDown2.Value, (int)numericUpDown3.Value);
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selected = dataGridView1.SelectedRows[0];
                DataGridViewCell first = selected.Cells[0];
                DataGridViewCell second = selected.Cells[1];
                DataGridViewCell third = selected.Cells[2];

                panel1.BackColor = Color.FromArgb(Convert.ToInt32(first.Value), Convert.ToInt32(second.Value), Convert.ToInt32(third.Value));
            }
        }
    }
}
