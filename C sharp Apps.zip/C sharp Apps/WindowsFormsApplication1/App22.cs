﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App22 : Form
    {
        private WindowsFormsApplication1.App22_Class.Semafor semafor = new WindowsFormsApplication1.App22_Class.Semafor();

        public App22()
        {
            InitializeComponent();
        }

        private void OsvjeziPrikaz()
        {
            pictureBox1.BackColor = SystemColors.Control;
            pictureBox2.BackColor = SystemColors.Control;
            pictureBox3.BackColor = SystemColors.Control;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string stanje = semafor.DohvatiStanje();

            if (stanje == "Crveno")
            {
                OsvjeziPrikaz();
                pictureBox1.BackColor = Color.Red;
                semafor.PromjeniStanje();
            }

            else if (stanje == "Zuto")
            {
                OsvjeziPrikaz();
                pictureBox2.BackColor = Color.Yellow;
                semafor.PromjeniStanje();
            }

            if (stanje == "Zeleno")
            {
                OsvjeziPrikaz();
                pictureBox3.BackColor = Color.Green;
                semafor.PromjeniStanje();
            }
        }
    }
}
