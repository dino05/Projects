﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.App22_Class
{
    class Semafor
    {
        private int TrenutnoStanje;
        private string[] Stanja = new string[3];
        private bool Silazno;

        public Semafor()
        {
            Stanja[0] = "Crveno";
            Stanja[1] = "Zuto";
            Stanja[2] = "Zeleno";

            Silazno = true;
            TrenutnoStanje = 0;
        }

        public void PromjeniStanje()
        {
            if (TrenutnoStanje == 0)
            {
                Silazno = true;
                TrenutnoStanje = 1;
            }
            else if (TrenutnoStanje == 1 && Silazno == true)
            {
                TrenutnoStanje = 2;
            }
            else if (TrenutnoStanje == 1 && Silazno == false)
            {
                TrenutnoStanje = 0;
            }
            else if (TrenutnoStanje == 2)
            {
                Silazno = false;
                TrenutnoStanje = 1;
            }
        }

        public string DohvatiStanje()
        {
            return Stanja[TrenutnoStanje];
        }
    }
}
