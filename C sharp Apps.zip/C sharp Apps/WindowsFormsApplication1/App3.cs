﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App3 : Form
    {
        public App3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.Parse(textBox1.Text) <= 255 && int.Parse(textBox2.Text) <= 255 && int.Parse(textBox3.Text) <= 255)
            {
                this.BackColor = Color.FromArgb((int.Parse(textBox1.Text)), (int.Parse(textBox2.Text)), (int.Parse(textBox3.Text)));
            }

            else
            {
                MessageBox.Show("Krivi unos!");
            }
        }
    }
}
