﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App4 : Form
    {
        public App4()
        {
            InitializeComponent();
        }

        Random random = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            int[] polje = new int[7];
            int noviBr;

            for (int i = 0; i < polje.Length; i++)
            {
                noviBr = random.Next(1, 39);

                if (polje.Contains(noviBr))
                {
                    i--;
                }

                else
                {
                    polje[i] = noviBr;
                }
            }

            label1.Text = polje[0].ToString();
            label2.Text = polje[1].ToString();
            label3.Text = polje[2].ToString();
            label4.Text = polje[3].ToString();
            label5.Text = polje[4].ToString();
            label6.Text = polje[5].ToString();
            label7.Text = polje[6].ToString();

            foreach (Control labela in this.Controls)
            {
                if (labela.GetType() == typeof(Label))
                {
                    if (int.Parse(labela.Text) < 20)
                    {
                        labela.ForeColor = Color.Green;
                    }
                    else
                    {
                        labela.ForeColor = Color.Red;
                    }
                }
            }
        }
    }
}
