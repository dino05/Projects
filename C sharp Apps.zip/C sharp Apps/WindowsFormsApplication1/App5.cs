﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App5 : Form
    {
        public App5()
        {
            InitializeComponent();
        }

        private void App5_Load(object sender, EventArgs e)
        {
            label1.Location = new Point((this.Width - label1.Width) / 2, (this.Height - label1.Height) / 2);
        }

        private void App5_Resize(object sender, EventArgs e)
        {
            label1.Location = new Point((this.Width - label1.Width) / 2, (this.Height - label1.Height) / 2);
            this.BackColor = System.Drawing.Color.White;
            label1.Text = "centar";
        }

        private void App5_MouseClick(object sender, MouseEventArgs e)
        {
            if ((MousePosition.X - this.Location.X) < this.Width / 2 && (MousePosition.Y - this.Location.Y) < this.Height / 2)
            {
                label1.Text = "SZ";
                this.BackColor = Color.Green;
            }

            if ((MousePosition.X - this.Location.X) < this.Width / 2 && (MousePosition.Y - this.Location.Y) > this.Height / 2)
            {
                label1.Text = "JZ";
                this.BackColor = Color.Red;
            }

            if ((MousePosition.X - this.Location.X) > this.Width / 2 && (MousePosition.Y - this.Location.Y) < this.Height / 2)
            {
                label1.Text = "SI";
                this.BackColor = Color.Blue;
            }

            if ((MousePosition.X - this.Location.X) > this.Width / 2 && (MousePosition.Y - this.Location.Y) > this.Height / 2)
            {
                label1.Text = "JI";
                this.BackColor = Color.Yellow;
            }
        }


    }
}
