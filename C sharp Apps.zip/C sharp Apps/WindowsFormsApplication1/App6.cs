﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App6 : Form
    {
        public App6()
        {
            InitializeComponent();

            for (int i = 1; i <= 12; i++)
            {
                listBox1.Items.Add(i);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();

            for (int i = 1; i <= DateTime.DaysInMonth(DateTime.Now.Year, listBox1.SelectedIndex + 1); i++)
            {
                listBox2.Items.Add(i);
            }
        }
    }
}
