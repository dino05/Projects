﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace WindowsFormsApplication1
{
    public partial class App7 : Form
    {
        public App7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] brojevi = textBox1.Text.Split(',');
            ArrayList lista = new ArrayList();
            textBox1.Clear();

            foreach (string br in brojevi)
            {
                lista.Add(int.Parse(br));
            }

            lista.Sort(null);

            for (int i = 0; i < lista.Count; i++)
            {
                textBox1.Text += lista[i];

                if (i < lista.Count - 1)
                {
                    textBox1.Text += ",";
                }
            }
        }
    }
}
