﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class App8 : Form
    {
        public App8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime godina = new DateTime(int.Parse(textBox1.Text), 1, 1);
            int b = int.Parse(textBox1.Text) + 1;
            int brojac = 0;
            textBox1.Clear();

            while (godina.Year != b)
            {
                godina = godina.AddDays(1);

                if (godina.Day == 13 && godina.DayOfWeek == DayOfWeek.Friday)
                {
                    brojac++;
                }
            }
            textBox1.Text = brojac.ToString();
        }
    }
}
