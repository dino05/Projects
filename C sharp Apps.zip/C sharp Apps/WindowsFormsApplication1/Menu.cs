﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.ToolTip opis = new System.Windows.Forms.ToolTip();
            opis.SetToolTip(this.button1, "App koja provjerava jednakost lozinki (minimalno 5 znakova, minimalno 3 velika slova, minimalno 1 znak # $ %)");
            opis.SetToolTip(this.button2, "App ispisuje godišnje doba na odabir datuma");
            opis.SetToolTip(this.button3, "App mijenja boju na unos RGB vrijednosti");
            opis.SetToolTip(this.button4, "App ispisuje loto brojeve (7/39)");
            opis.SetToolTip(this.button5, "App ispisuje stranu svijeta na klik miša");
            opis.SetToolTip(this.button6, "App na odabir mjeseca ispisuje broj dana za odabrani mjesec");
            opis.SetToolTip(this.button7, "App sortira brojeve odvojene zarezom");
            opis.SetToolTip(this.button8, "App ispisuje broj petaka za zadanu godinu");
            opis.SetToolTip(this.button9, "App ispisuje broj preostalih dana do idućeg petka");
            opis.SetToolTip(this.button10, "App generira 10 progress barova koji svake sekunde mijenjaju vrijednost");
            opis.SetToolTip(this.button11, "App ispisuje statistiku slova (koliko se koje slovo pokazuje puta u zadanoj rijeci)");
            opis.SetToolTip(this.button12, "App sluzi kao preglednik slika, otvori se folder sa slikama pa se onda klikom na sliku one mijenjaju");
            opis.SetToolTip(this.button13, "App predstavlja Loto, unosi se 7 brojeva, nakon klika na gumb app ispisuje izvucene brojeve i poruku s nagradom (<5 nema nagrade, 5 - 1000kn, 6 - 10 000kn, 7 - 1 000 000kn)");
            opis.SetToolTip(this.button14, "App racuna uniju, presjek i razliku skupa brojeva (u polja se unose cijeli brojevi koji se dodaju u liste, a u trecu listu se ispisuje rezultat)");
            opis.SetToolTip(this.button15, "App odabirom proizvoda i kompanije provjerava u bazi da li proizvod pripada odabranoj kompaniji, ako pripada oznaci zeleno, ako ne pripada oznaci crveno");
            opis.SetToolTip(this.button16, "App upisom sirine i visine pravokutnika racuna povrsinu, opseg i dijagonalu");
            opis.SetToolTip(this.button17, "App je igra koja prikazuje u kucicama brojeve na 5 sekundi, brojeve je potrebno zapamtit i upisat u donje kucice. Ako ste promasili prikazane brojeve ispisuje se poruka Pokusajte ponovo");
            opis.SetToolTip(this.button18, "App predstavlja imenik za unos kontakta s pripadajucom grupom, klikom na gumb Dodaj novi se dodaje novi kontakt (zabranjen je unos podataka prije klika na gumb), svi kontakti se dodaju u prikazanu listu, te se mogu pretraživat u polju ispod liste");
            opis.SetToolTip(this.button19, "App predstavlja registar vozila, u listu se upisuju podaci koje korisnik zadaje prilikom unosa vozila, a aplikacija uz to prikazuje trenutni broj vozila po kategoriji");
            opis.SetToolTip(this.button20, "App sluzi za upisivanje temperatura s nazivom, ciji se podaci prikazuju u tablici te se ispod tablice ispisuje prosjecna vrijednost svih temperatura");
            opis.SetToolTip(this.button21, "App sluzi za dodavanje boja u tablicu, boje se dodaju po njihovim RGB vrijednostima te po nazivu, dok se u pravokutniku sa strane prikazuje odabrana boja");
            opis.SetToolTip(this.button22, "App simulira rad semafora, svaku sekundu se mijenja boja po shemi: crveno, zuto, zeleno, zuto, crveno, zuto, zeleno...");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form app1 = new App1();
            app1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form app2 = new App2();
            app2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form app3 = new App3();
            app3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form app4 = new App4();
            app4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form app5 = new App5();
            app5.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form app6 = new App6();
            app6.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form app7 = new App7();
            app7.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form app8 = new App8();
            app8.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form app9 = new App9();
            app9.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form app10 = new App10();
            app10.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form app11 = new App11();
            app11.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form app12 = new App12();
            app12.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form app13 = new App13();
            app13.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Form app14 = new App14();
            app14.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Form app15 = new App15();
            app15.Show();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Form app16 = new App16();
            app16.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Form app17 = new App17();
            app17.Show();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Form app18 = new App18();
            app18.Show();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form app19 = new App19();
            app19.Show();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Form app20 = new App20();
            app20.Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Form app21 = new App21();
            app21.Show();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Form app22 = new App22();
            app22.Show();
        }
    }
}
