﻿namespace WindowsFormsApplication1 {
    
    
    public partial class northwndDataSet {
    }
}

namespace WindowsFormsApplication1.northwndDataSetTableAdapters {
    
    
    public partial class ProductsTableAdapter {
    }
}
